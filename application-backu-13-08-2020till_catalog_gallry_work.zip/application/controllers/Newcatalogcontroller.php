<?php error_reporting(0);
defined('BASEPATH') OR exit('No direct script access allowed');

class Newcatalogcontroller extends CI_Controller {

	
	public function __construct()
	{
	parent::__construct();
	$this->load->database();
	$this->load->Model('DataModel');
	$this->load->Model('EngineerModel');
    $this->load->Model('SupplierModel');
	$this->load->Model('ProjectModel');
	$this->load->Model('ProductCategoryModal');
	$this->load->Model('ProductModel');
	$this->load->library('upload');
    $this->load->library('image_lib');
	$this->load->Model('CetaloguesModels');
	
	}//$route['newCetalogues'] = 'newcatalogcontroller/newCetalogues';

	public function newCetalogues(){ 
		if(isset($_SESSION['status'])){
		if(isset($_POST['uploadpdf']))
		{ 
			if(isset($_SESSION['Current_Business'])){
					 $bid=$_SESSION['Current_Business'];
				 }
				 else
				 {
					 $bid=$_SESSION['status']['business_id'];
				 }
				 $sectionid=$_REQUEST['sectionid'];
			$table="cetalouges";
			$pdffile=$_FILES['pdffile'];
			$pdfname=$pdffile['name'];
			$storepdf=rand().time();
			$url=site_url().'images/cetalogues/'.$storepdf;
			$pdfdate=date("d/m/Y");
			$size=$_FILES['pdffile']['size'].'bytes';
			$productcetalog=array('name'=>$storepdf,'bussinessid'=>$bid,'url'=>$url,'size'=>$size,'date'=>$pdfdate,'sectionid'=>$sectionid);
			if(move_uploaded_file($pdffile["tmp_name"],"images/cetalogues/".$storepdf))
			{
				$insert=$this->CetaloguesModels->insert($table,$productcetalog);
				if($insert)
				{
					redirect('newCetalogues');
				}
			}
		}else{
			$this->load->view('header.php');
			$this->load->view('sidebar.php');
			$this->load->view('newcatalogview.php');
			$this->load->view('footer.php');
		     }
		}
		//SESSION CHECK
			  else{ 
		redirect('dashboard');
	    }	
	}
	public function DeleteCateLouges()
	{
		$id=$_GET['id'];
		$this->CetaloguesModels->DeleteCateLouges($id);
	}
	public function newGetCateLouges(){   //api
		$this->load->view('api/newcatalogapi.php');
	}
    /**********************add section **************/
	public function add_section()
	{
		if($this->input->post('addsec'))
		{
			$bid=$this->input->post('bid');
			$section=$this->input->post('section');
		
			$file=$_FILES['cover'];
			$filenam=$file['name'];
			$tmpname=$file['tmp_name'];
			$storecover=rand().time();
			$url=site_url().'images/CetalogSectionCover/'.$storecover;
			
			if(move_uploaded_file($tmpname,"images/CetalogSectionCover/".$storecover))
			{
				 $data = array('business_id'=>$bid,'section_name'=>$section,'cover_image'=>$url);
				 $this->db->insert('dev_cetalog_section',$data);
				 if($this->db->affected_rows())
				 {
						redirect('newCetalogues');
				 }
				 else
				 {
					 	redirect('newCetalogues');
				 }
			}
			else
			{
				 	redirect('newCetalogues');
			}
				 
			
		}
	}

	
	//show 
      public function ShowCatalogBySection()
	  {
		  if($_REQUEST['selectedid']!=0)
		  {
			  $sectionid=$_REQUEST['selectedid'];
			  $dataobj=$this->db->query("select * from cetalouges where sectionid='$sectionid'");
			  $dataarray=$dataobj->result_array();
			  echo json_encode($dataarray);
		  }
		  else
		  {
			  echo "0";
		  }
	  }
}
